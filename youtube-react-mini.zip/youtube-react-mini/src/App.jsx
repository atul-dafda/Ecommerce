const App = () => {
  return <div>Hello world!</div>;
};

export default App;